MoneyToFlowsBot - Render V21 package

Files:
- bot.py (main bot code, polling mode with Flask healthcheck)
- requirements.txt
- Procfile
- README_RENDER.md

IMPORTANT:
- Do NOT commit your TOKEN to GitHub.
- On Render, set the following Environment Variables for your service:
  TOKEN = <your telegram bot token>
  ADMIN_ID = 2083513871
  ADMIN_USERNAME = @RUBENHRM777
  ACHAT_LINK = https://sgzxfbtn.mychariow.shop/prd_8ind83
  PRODUCT_NAME = Pack Formations Business 2026
  SEUIL_RECOMPENSE = 5
  REWARD_PER_REF = 1000.0

Render deployment quick steps:
1. Create a new service on Render, choose Web Service (so gunicorn serves the Flask app)
2. Connect your GitHub repo containing these files
3. Build command: pip install -r requirements.txt
4. Start command: gunicorn bot:app_flask
5. Add the Environment Variables above (TOKEN must be your bot token)
6. Deploy and check logs for "🤖 Bot démarré (polling)." in logs.

